package particles;


public class Particle {


}
